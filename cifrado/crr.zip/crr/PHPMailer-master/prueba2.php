<?php
$content = '------=_Part_9229287_44932017.1447781803661
Content-Type: multipart/related;
	boundary="----=_Part_9229288_1405649622.1447781803661"

------=_Part_9229288_1405649622.1447781803661
Content-Type: text/html;charset=ISO-8859-1
Content-Transfer-Encoding: quoted-printable

 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no">


	<meta charset="utf-8">
    <style type="text/css">
    table, tr, td, span, a {
        -webkit-text-size-adjust:none;
    }

    @media only screen and (max-width: 599px) {

        table[class="slogan-app"] {
            text-align: center;
            width: 100%;
        }

        td[class="logo-left"] {
            width: 50%;
            text-align: right;
        }

        td[class="logo-right"] {
            width: 50%;
            text-align: left;
        }

        td[class="spacer"]{
            display: none;
        }

    }

    @media only screen and (max-width: 710px) {
        .primary-action {
            font-size: 17px!important;
            display: inline-block;
        }

        .secondary-action {
            display: inline-block;
            text-align: center;
        }

    }

    @media only screen and (max-width: 528px) {
        .primary-action {
            float: none!important;
        }

    }

    @media only screen and (max-width: 460px) {
        div.primary-action {
            margin-right: 0!important;
        }
    }
    </style>


	<table width="100%" cellspacing="0" cellpadding="0" border="0">
		<tbody><tr>
			<td class="logo" align="left" style="padding:10px 0 15px 0">
				<img alt="MercadoLibre" border="0" title="MercadoLibre" width="132" height="33" src="http://static.mlstatic.com/org-img/emails/logos/logo-mercadolibre-new.gif">
			</td>
		</tr>
		<tr>	
			<td width="100%" style="border-top:solid 1px #E8E8E8;display:block"></td>
		</tr>
		<tr>
			<td height="15" style="font-size:1px">&nbsp;</td>
		</tr>
	</tbody></table>


<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td width="40">
            
                <img alt="Congrats" height="32" width="32" src="http://static.mlstatic.com/org-img/emails/icons/ico_ok2.gif">
            
		</td>
		<td style="font-family:Arial; font-size:20px; color:#468847; font-weight:normal;">
				
					Vendiste, �buen trabajo!
				
		</td>
	</tr>
	
</tbody></table>
<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tbody><tr>
		<td>
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tbody><tr valign="top">
					<td style="width:90px">
						<span style="border:1px solid #cccccc;display:block;">
							<a href="https://myaccount.mercadolibre.com.ve/sales/vop?orderId=1024848373"><img src="https://a248.e.akamai.net/mlv-s2-p.mlstatic.com/22438-MLV20230533861_012015-I.jpg" style="display:block;" width="90" height="90"></a>
						</span>	
					</td>
					<td>	
						<table cellpadding="0" cellspacing="0" border="0">
						   <tbody><tr>
					   			<td style="font-family:Arial; font-size:14px; color:#666666;padding:0 20px 6px 15px;line-height:1.4;">Camara Principal Trasera+flash Apple Iphone 4g + Instalacion</td>
					   		</tr>
						    <tr>
						    	<td style="font-family:Arial; font-size:12px; color:#999999;padding:0 20px 6px 15px">
									
									Cantidad: 1
								</td>
						    </tr>
						    <tr>
						    	<td style="font-family:Arial; font-size:16px; color:#B22C00;padding:0 20px 0 15px">Bs. 1.300,00 
						    		<span style="font-family:Arial; font-size:14px; color:#666666;">
							    		
						    					c/u
				    					
			    					</span>
				    			</td>
						    </tr>
						</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	<tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>





<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:18px; color:#333333;">
			Pago
		</td>
	</tr>
	<tr><td height="3" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>



<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td width="145" style="font-family:Arial; font-size:14px; color:#666666">
			
				Tu comprador eligi� acordar el pago directamente contigo.
			
				
			
			
		</td>
	</tr>
	<tr><td height="15" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>


<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr style="display:block; padding:5px 0">
		<td width="80" style="font-family:Arial; font-size:14px; color:#666666">
			Producto
		</td>
		<td style="font-family:Arial; font-size:14px; color:#666666">
			Bs. 1.300,00
		</td>
	</tr>
    
    <tr style="display:block; padding:5px 0">
    <td valign="top" width="80" style="font-family:Arial; font-size:14px; color:#666666; border-top: solid 1px #DDDDDD; padding:5px 0">

        Total:
    </td>
    <td valign="top" style="font-family:Arial; font-size:14px; color:#B22C00; border-top: solid 1px #DDDDDD; padding:5px 0">
        Bs. 1.300,00
    </td>
</tr>
</tbody></table>




	

<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>

<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:18px; color:#333333;padding-bottom: 5px;">
			Env�o
		</td>
	</tr>
	
		<tr>
			<td style="font-family:Arial; font-size:14px; color:#666666;line-height:1.4;">
				Tu comprador eligi� acordar el env�o directamente contigo.
			</td>
		</tr>
	
	
	
</tbody></table>
<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>
<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:18px; color:#333333;padding-bottom:10px;">
			Comprador
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;padding-bottom:5px;line-height:1.4;">
			 LULU SHOPCREATIONS (LULU SHOPCREATIONS)
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;padding-bottom:5px;line-height:1.4;">
			<a href="mailto:ventas@lulushopve.com" style="font-family:Arial; font-size:14px; color:#0637B3; text-decoration:none">
			ventas@lulushopve.com</a>
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;padding-bottom:5px;line-height:1.4;">
			
			<a style="font-size:14px; color:#0637b3; text-decoration:none" href="tel:+ 04147548364"> 04147548364</a>
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;line-height:1.4;">
	 		 San Cristobal, T�chira
		</td>
	</tr>
</tbody></table>

<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>






		 <!-- custom / meenvios not accord /no shiiping  -->
			


	<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:16px; color:#333333; font-weight:normal;padding-bottom:3px;line-height:1.4;">
			�C�mo me entero que ya me pagaron?
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666; padding-bottom:15px;line-height:1.4;">
			Para pagos por transferencia o con cheque, verifica que los datos sean correctos y confirma que se haya depositado en tu cuenta. Cuando te paguen en efectivo, cuenta el dinero y verifica su autenticidad.
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;line-height:1.4;">
			P�dele a tu comprador que te pague por MercadoPago y env�a el producto solo cuando el dinero est� acreditado en tu cuenta.
		</td>
	</tr>
</tbody></table>
	<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>





			


	<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:16px; color:#333333; font-weight:normal;padding-bottom:3px;line-height:1.4;">
			�C�mo lo entrego?
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666; padding-bottom:15px;line-height:1.4;">
			Encu�ntrate en un lugar concurrido para hacer el intercambio.
		</td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666;line-height:1.4;">
			Si vas a enviar el producto, usa servicios con seguro, env�alo a nombre del comprador y guarda copias de los recibos de env�o.

		</td>
	</tr>
</tbody></table>
	<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>


		



<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
	<tbody><tr>
		<td style="font-family:Arial; font-size:14px; color:#666666">
			Que sigan los �xitos,
	    </td>
	</tr>
	<tr>
		<td style="font-family:Arial; font-size:14px; color:#666666">
			El equipo de MercadoLibre
		</td>
	</tr>
	<tr><td height="25" style="font-size:1px">&nbsp;</td></tr>
</tbody></table>
<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:0 20px 0 0">
		<tbody><tr>
			<td style="padding-top:10px;border-top: solid 1px #E8E8E8;">
				<span style="font-family:Arial; font-size:12px; color:#999999">
					No respondas este e-mail.
					<a href="http://ayuda.mercadolibre.com.ve/" style="font-family:Arial; font-size:12px; color:#0637B3; text-decoration:none">Ayuda</a>.
				</span>
			</td>
		</tr>
		<tr><td height="15" style="font-size:1px">&nbsp;</td></tr>
	</tbody></table>
<img width="1" height="1" src="https://www.mercadolibre.com.ve/gz/emails/pixel?email_id=6422563534&amp;email_template=END_AUCT&amp;user_id=127057322&amp;email_address=itechnologystorec.a@gmail.com&amp;site_id=MLV&amp;sent_date=2015-11-17T13:36:43.656-04:00&amp;v=1&amp;hash=86f1660ac080eb14b7834ab9e49a9d20558eeea3">


	<img src="http://www.mercadolibre.com.ve/notifications/pixel?notification_source=mail-order-confirmed&amp;notification_id=1024848373&amp;notification_user_id=127057322&amp;notification_hash=5ceea4f1117a42d0d6b2b4148f1592597877cff2" width="1" height="1">

------=_Part_9229288_1405649622.1447781803661--

------=_Part_9229287_44932017.1447781803661--';
$pos = strpos($content, 'mailto', 1); // $pos = 7, no 0
echo $pos;
$rest = substr($content, $pos, 170); 
echo $rest.'<br>';
$porciones = explode(':', $rest);
echo $porciones[0]; // porción1
echo "<br>1";
echo $porciones[1]; // porción2
echo "<br>2";
$porciones2 = explode('"', $porciones[1]);
echo 'este es el correo: '.$porciones2[0]; // porción1
echo "<br>3";
echo $porciones2[1]; // porción2

require_once('PHPMailerAutoload.php');
$mail = new PHPMailer();
//indico a la clase que use SMTP
$mail->IsSMTP();
//permite modo debug para ver mensajes de las cosas que van ocurriendo
$mail->SMTPDebug = 2;
//Debo de hacer autenticación SMTP
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
//indico el servidor de Gmail para SMTP
$mail->Host = "smtp.gmail.com";
//indico el puerto que usa Gmail
$mail->Port = 465;
//indico un usuario / clave de un usuario de gmail
$mail->Username = "itechnologystorec.a@gmail.com";
$mail->Password = "13adqezc";
$mail->SetFrom('itechnologystorec.a@gmail.com', 'iTechnology Store CA');
$mail->AddReplyTo("itechnologystorec.a@gmail.com","iTechnology Store CA");
$mail->Subject = "Datos de concretar";
$mail->MsgHTML("<html>
<head>
	<meta charset='UTF-8'>
<link href='https://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
<style>
	body{
		font-family: 'Droid Sans', sans-serif;
	}
	table{
		background: rgba(160,160,160,0.2);
		border-radius: 5px;
	}
</style>
</head>
<body>
<table width='600px' CELLPADDING='0'
	BORDER='1' align='center'
	>
<tr><td><b>DATOS PARA CONCRETAR TU COMPRA</b></td></tr>

<tr><td><b>Le suministramos Las cuentas Bancarias para depósito o transferencia bancaria.</b></td></tr>

<tr><td>BANCO BANESCO<br>
CTA. Corriente<br>
0134-0340-67-3403054386<br>
A Nombre: Gabriel García<br>
V- 18.762.507</tr>
 
<tr><td>BANCO BBVA PROVINCIAL<br>
CTA. Corriente<br>
0108-0364-17-0100047829<br>
A Nombre: Gabriel García<br>
V- 18.762.507</td></tr>
 
<tr><td>BANCO SOFITASA<br>
CTA. Corriente<br>
0137-0005-26-0001771271<br>
A Nombre: Gabriel García<br>
V- 18.762.507</td></tr>

<tr><td>BANCO VENEZUELA<br>
CTA. Corriente<br>
0102-0219-18-0000137313<br>
A Nombre: Bonny García<br>
V-9.237.684</td></tr>
</table>
<table width='600px' CELLPADDING='0'
	BORDER='2' align='center'
	>
	<tr><td><h5 style='color:red;'>AGRADECEMOS QUE DESPUES DEL PAGO PUEDA REENVIARNOS ESTE MISMO FORMATO.</h5> <h4 style='color:red;' >COPIA Y PEGALO TAL CUAL Y LLENA LOS CAMPOS ESPECIFICADOS</h4></td></tr>

<tr><td><b>DATOS DE ENVIO:</b><br>
<b>1.</b> Nombre y apellido: <b>Borra y escribe aqui</b><br>
<b>2.</b> Cédula: <b>Borra y escribe aqui</b><br>
<b>3.</b> Teléfono: <b>Borra y escribe aqui</b><br>
<b>4.</b> Ciudad y estado: <b>Borra y escribe aqui</b><br> 
<b>5.</b> “Dirección EXACTA, con calle y número de casa o apartamento” (“OJO' no nos hacemos responsables por perdidas de paquetes o retrasos en consecuencia de direcciones incompletas): <b>Borra y escribe aqui</b><br>
<b>6.</b> Empresa por donde se le enviará su paquete ¿MRW o DOMESA?: <b>Borra y escribe aqui</b><br>
<b>7.</b> Si su paquete va para una OFICINA MRW por favor suministrar el código de la oficina: <b>Borra y escribe aqui</b></td></tr> 

<tr><td><b>DATOS PARA CONFORMAR SU PAGO</b><br>
<b>0.</b> Fecha en la que realizó el pago:<b>Borra y escribe aqui</b><br>
<b>1.</b> Banco del cuál transfiere usted:<b>Borra y escribe aqui</b><br> 
<b>2.</b> Banco al Cuál nos realiza la Transferencia o deposito:<b>Borra y escribe aqui</b><br>
<b>3.</b> Canceló usted con tarjeta de crédito por medio de MercadoPago?:<b>Borra y escribe aqui</b><br>
<b>4.</b> Si cancelo con tarjeta de crédito por mercado pago es OBLIGATORIO anexar copia de cédula del titular de la cuenta. Si el paquete lo recibe un tercero que no sea el TITULAR DE LA CUENTA deberá anexar OBLIGATORIAMENTE, copia de cédula del TITULAR y el TERCERO que recibe, de recibir el mismo titular de la cuenta no aplica este párrafo.<b>Borra y escribe aqui</b><br> 
<b>5.</b> Número de Referencia o Movimiento de transferencia o deposito:<b>Borra y escribe aqui</b><br>
<b>6.</b> Monto que cancela por el artículo:<b>Borra y escribe aqui</b><br>
<b>7.</b> Canceló el envío junto con el deposito? (No es obligatorio cancelar el envío usted puede cancelarlo al recibir el paquete):<b>Borra y escribe aqui</b><br>
<b>8.</b> Enviar por correo junto con los datos de envío una copia o PRINT de pantalla o foto del comprobante de transferencia o depósito:<b>Borra y escribe aqui</b><br>
<b>9.</b> Articulo que ¿COMPRO, CANTIDAD, MODELO O COLOR?:<b>Borra y escribe aqui</b><br>
<b>10.</b> Seudónimo de  mercado libre para calificarlo:<b>Borra y escribe aqui</b><br></td></tr>
</table>
<table width='600px' CELLPADDING='0'
	BORDER='1' align='center'
	>
	<tr><td><b>TERMINOS Y CONDICIONES:</b><br>
<b>1.</b> <b style='color:red;'>Luego de ofertar y cancelar debe enviar el formulario virtual a nuestro correo electrónico.</b><br>
<b>2.</b> Todos los pedidos se despachan en un lapso no mayor de 24 a 48 horas hábiles.<br>
<b>3.</b> Se le notificara únicamente vía correo electrónico el estatus de su compra.<br>
<b>4.</b> No nos hacemos responsables por pérdidas o retrasos por parte de MRW, ZOOM y DOMESA; son empresas totalmente independientes y sin relación con iTechnology Store C.A.<br>
<b>5.</b> No apartamos mercancía, nuestro Stock está en constante movimiento, tanto en tienda física como por mercado libre, si el cliente oferta debe anunciar por correo o llamar directamente a nuestra ejecutiva de ventas para concretar su compra.<br>
<b>6.</b> No reembolsamos dinero, se cambia por mercancía.<br>
<b>7.</b> Los precios publicados se mantienen por un lapso de 3 días luego de su oferta, pasado el tiempo puede estar sujeto a cambios por encima del precio ofertado.<br>
<b>8.</b> Horario de atención al cliente, Lunes a Viernes de 8:00 AM a 12:00 PM y de 2:00 PM a 6:00 PM, Sábados de 8:00 AM a 1:00 PM.</td></tr>
<tr><td><b>GARANTIAS</b><br>
<b>1.</b> Teléfonos celulares, Tablet, iPod o Reproductores, Computadoras tienen garantía de 6 Meses.<br>
<b>2.</b> Repuestos internos de Teléfono como Flex, Auricular, Corneta y Antena tienen Garantía de 15 Días.<br>
<b>3.</b> Repuestos de Teléfono Pantalla DISPLAY  LCD, Táctiles y Micas de Vidrio solo tienen Garantía al momento de la entrega, recomendablemente que el cliente pruebe el articulo en nuestras instalaciones porque no hay garantía desde el momento que el cliente se lleve el repuesto.<br>
<b>4.</b> Accesorios como Laminas protectoras BUFF y Vidrio templado, Cables, Cargadores, Audífonos y todo tipo de accesorios tiene una Garantía de 7 Días.<br>
<b>5.</b> Para Clientes que reciben su paquete con MRW, ZOOM o DOMESA, Tienen el mismo tiempo de garantía sin contar el día que se envía, se empieza a contar un día después de enviado.<br>
<b>6.</b> Todos los Fletes por Cambios y Garantías corren por cuenta del Comprador, No recibimos paquetes COD, El flete debe ser Pago por el Cliente.<br>
<b>7.</b> Todo paquete devuelto por Cambio o Garantía debe estar en ÓPTIMAS condiciones físicas tanto el equipo como su caja con todos sus envoltorios y plásticos.<br>
<b>8.</b> Cualquier tipo de calificación negativa, ofensiva, obscena o reclamos por mercado libre podrá perder la cobertura de garantía y estará sujeto a realizar los cambios pertinentes para poder retomar su amplia cobertura de garantía.<br>
<b>9.</b> Al momento de solicitar cobertura de garantía o cambio debe hacerlo directamente por correo, donde nuestras ejecutivas de ventas  estarán atendiendo sus necesidades y dando a conocer el procedimiento de garantía o cambio.<br>
 
<h4 style='color:red;'>LAS GARANTIAS SON POR DEFECTOS DE FABRICA, NO APLICA POR MAL USO, MALA MANIPULACION O DESCONOCIMIENTO DEL MISMO.</h4>
</table>
<table width='600px;' align='center' cellpadding='0' cellspacing='0'>
	<tr><td style='background-color:rgb(0,173,238); ' height='40px; '><span style='margin-left:10px; color:white;'>íTECHNOLOGY STORE, C.A</span><span style='float:right; color:white; margin-right:20px;'>RIF: J-40324148-1</span></td></tr>
	<tr><td><br><span style='margin-left:10px;'><b>Ejecutiva De Ventas:</b></span> <span style='margin-left:10px;'>Lcda. Greisy Colmenares</span></td></tr>
	<tr><td><br><span style='margin-left:10px;color:rgb(0,173,238);' ><img src='http://itstore.com.ve/imagenes/iconos/whats.png' width='20px' height='20'></span> <span style='margin-left:0px; color:rgb(37,168,23);'>0414-7048552</span><br><br><span style='margin-left:10px;'> <b>Visitanos en:</b><a href='http://www.itstore.com.ve/' style='text-decoration:none;color:rgb(0,173,238); ' target='_blank'><u> www.itstore.com.ve</u></a></span></td></tr>
	<tr><td><br><span style='margin-left:10px;'><a href='https://www.facebook.com/iTechnology-Store-CA-706893352674088/timeline/' target='_blank'><img src='http://itstore.com.ve/imagenes/iconos/facebook.jpg' width='50px' height='50px'></a></span> <span style='margin-left:10px;'><a href='https://twitter.com/iTStoreCA' target='_blank'><img src='http://itstore.com.ve/imagenes/iconos/twitter.jpg' width='50px' height='50px'></a></span> <span style='margin-left:10px;'><a href='http://instagram.com/itstoreca' target='_blank'><img src='http://itstore.com.ve/imagenes/iconos/Instagram.jpg' width='50px' height='50px'></a></span><span style='margin-left:10px;'><a href='http://listado.mercadolibre.com.ve/_DisplayType_G_CustId_127057322' target='_blank'><img src='http://itstore.com.ve/imagenes/iconos/mercadolibre1.jpg' width='50px' height='50px'></a></span></td></tr>
	<tr><td><br></td></tr>
</table>
</body>
</html>");
//indico destinatario
$address = "ander0426@gmail.com";
$mail->AddAddress($address, "comprador");
if(!$mail->Send()) {
echo "Error al enviar: " . $mail->ErrorInfo;
} else {
echo "Mensaje enviado!";
}
?>